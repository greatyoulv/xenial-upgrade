/* This file is auto generated, version 93-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#93-Ubuntu SMP Fri Mar 31 14:07:41 UTC 2017"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-17"
#define LINUX_COMPILER "gcc version 5.4.0 20160609 (Ubuntu 5.4.0-6ubuntu1~16.04.4) "
